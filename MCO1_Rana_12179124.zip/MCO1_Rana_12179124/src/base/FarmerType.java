package base;

public enum FarmerType {
    NOVICE,
    REGISTERED,
    DISTINGUISHED,
    LEGENDARY,
}
