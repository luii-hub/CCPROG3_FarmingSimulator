package base;

public enum CropType {
    ROOT_CROP,
    FLOWER,
    FRUIT_TREE,
}