package base;

public enum TileStatus {
    ROCK,
    UNPLOWED,
    PLOWED,
    PLANT,
    SEED, //Basically still a seed and growing
    WITHERED,

}
